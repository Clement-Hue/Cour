package state;

import network.Network;
import network.Node;

public class Disconnected implements State {

	@Override
	public void connection(final Node node) {
		System.out.println("user " + node.getIdUser() + " Connection");
		Network.listNode[node.getAddress()] = node;
		node.setState(new Connected());
	}

	@Override
	public void disconnection(final Node node) {

	}

}
