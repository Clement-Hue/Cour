package state;

import network.Network;
import network.Node;

public class Connected implements State {

	@Override
	public void connection(final Node node) {

	}

	@Override
	public void disconnection(final Node node) {
		System.out.println("user " + node.getIdUser() + " Deconnexion");
		Network.listNode[node.getAddress()] = null;
		node.setState(new Disconnected());
	}

}
