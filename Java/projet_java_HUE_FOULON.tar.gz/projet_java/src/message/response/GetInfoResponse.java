package message.response;

import java.util.UUID;

import network.Network;
import network.UserData;

// Répond à une requête GetInfo en envoyant les informations non périssables du noeud.
public class GetInfoResponse extends Response {
	private final int address;
	private final String firstName;
	private final String lastName;
	private final int idUser;

	public GetInfoResponse(final int idFirstSender, final int idFinalReceiver, final UUID requestId,
			final UserData userData, final boolean cache) {
		super(idFirstSender, idFinalReceiver, requestId);
		this.address = userData.getAddress();
		this.firstName = userData.getFirstName();
		this.lastName = userData.getLastName();
		this.idUser = userData.getIdUser();
		this.cache = cache;
	}

	public final int getAddress() {
		return address;
	}

	public final String getFirstName() {
		return firstName;
	}

	public final int getIdUser() {
		return idUser;
	}

	public final String getLastName() {
		return lastName;
	}

	@Override
	protected void performSending(final int addressReceiver) {
		try {
			printSending(addressCurrentSender, addressReceiver);
			Network.listNode[addressReceiver].getMessageHandler().handle(this);
		} catch (final NullPointerException exc) {
			printNodeNotReachable();
			Network.listNode[addressCurrentSender].getFailedHandler().handle(this);
		}
	}
}
