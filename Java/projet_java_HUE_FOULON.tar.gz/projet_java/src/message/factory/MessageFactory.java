package message.factory;

import java.util.UUID;

import message.Message;
import message.request.Request;
import network.Node;
import network.UserData;

public abstract class MessageFactory {
	protected Node node;
	protected int idFirstSender;

	public MessageFactory(final Node node) {
		this.idFirstSender = node.getIdUser();
		this.node = node;
	}

	protected abstract Request createRequest(int idFinalReceiver);

	protected abstract Message createResponse(int idFinalReceiver, UUID requestId, UserData userData, boolean cache);

	/**
	 * Crée une requête et l'envoie, attend une réponse avec un timeout
	 *
	 * @param idFinalReceiver id du destinataire final
	 */
	public void newRequest(final int idFinalReceiver) {
		final Request req = this.createRequest(idFinalReceiver);
		node.sendMessage(req);
		node.waitForResponse(idFinalReceiver, req);
	}

	/**
	 * Crée une réponse et l'envoie
	 *
	 * @param idFinalReceiver id du destinataire final
	 * @param requestId       id de la requéte associée à la réponse
	 * @param userData        données de l'utilisateur envoyées dans la réponse
	 * @param cache           précise si ces données proviennent d'un cache
	 */
	public void newResponse(final int idFinalReceiver, final UUID requestId, final UserData userData,
			final boolean cache) {
		node.sendMessage(this.createResponse(idFinalReceiver, requestId, userData, cache));
	}
}
