package message.request;

import network.Network;

// Requête envoyée à un noeud particulier pour récupérer ses informations non périssables.
public class GetInfoRequest extends Request {
	public GetInfoRequest(final int idFirstSender, final int idFinalReceiver) {
		super(idFirstSender, idFinalReceiver);
	}

	@Override
	protected void performSending(final int addressReceiver) {
		try {
			printSending(addressCurrentSender, addressReceiver);
			Network.listNode[addressReceiver].getMessageHandler().handle(this);
		} catch (final NullPointerException exc) {
			printNodeNotReachable();
			Network.listNode[addressCurrentSender].getFailedHandler().handle(this);
		}
	}

}
