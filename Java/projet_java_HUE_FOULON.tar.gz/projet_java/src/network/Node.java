package network;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import handler.Handler;
import handler.HandlerFactory;
import handler.failMessage.FailedMessageHandler;
import handler.message.MessageHandler;
import message.Message;
import message.factory.GetAllNeighborFactory;
import message.factory.GetInfoFactory;
import message.factory.GetInfoPerissableFactory;
import message.factory.MessageFactory;
import message.request.Request;
import message.response.GetInfoPerissableResponse;
import state.Connected;
import state.State;

public class Node extends UserData {
	private State state = new Connected();
	private List<Cache> listNeighbor = new ArrayList<>(5);
	MessageHandler messageHandler = HandlerFactory.createHandler(this);
	Handler failedHandler = new FailedMessageHandler(this);
	MessageFactory getInfo = new GetInfoFactory(this);
	MessageFactory getInfoPerissable = new GetInfoPerissableFactory(this);
	MessageFactory getAllNeighbor = new GetAllNeighborFactory(this);

	public Node(final int idUser, final String firstName, final String lastName) {
		super(idUser, firstName, lastName);
	}

	public void addPublication(final Publication publication) {
		this.listPublication.add(publication);
	}

	public void addUserToCache(final Node neighbor) {
		if (listNeighbor.size() > 5)
			return;
		listNeighbor.add(new Cache(neighbor));
	}

	public void connection() {
		this.state.connection(this);
	}

	public void disconnection() {
		this.state.disconnection(this);
	}

	/**
	 * Verifie si le noeud courant possède comme voisin l'id passé en paramètre. Si
	 * oui, renvoie les infos en mémoire sur ce voisin. Renvoie null sinon
	 *
	 * @param userId id de l'user
	 * @return les données du voisin si il existe
	 */
	public Cache getCacheData(final int userId) {
		for (final Cache voisin : getListNeighbor()) {
			if (voisin.getIdUser() == userId)
				return voisin;
		}
		return null;
	}

	public Handler getFailedHandler() {
		return failedHandler;
	}

	public final MessageFactory getGetAllNeighbor() {
		return getAllNeighbor;
	}

	public final MessageFactory getGetInfo() {
		return getInfo;
	}

	public final MessageFactory getGetInfoPerissable() {
		return getInfoPerissable;
	}

	public final List<Cache> getListNeighbor() {
		return listNeighbor;
	}

	public MessageHandler getMessageHandler() {
		return messageHandler;
	}

	public final State getState() {
		return state;
	}

	/**
	 * Check si le receiver est parmis mes voisins, si oui l'envoie
	 *
	 * @param msg
	 * @return true si le receiver est parmis mes voisins et le message est envoyé
	 */
	private boolean isReceiverInCache(final Message msg) {
		final Cache neigh = this.getCacheData(msg.getIdFinalReceiver());
		if (neigh != null) {
			msg.send(this.address, neigh.getAddress());
			return true;
		}
		return false;
	}

	public void removeUserFromCache(final Cache neighbor) {
		listNeighbor.remove(neighbor);
	}

	/**
	 * Envoie le message au finalReceiver si il est parmis les voisins sinon
	 * l'envoie à tous les voisins
	 *
	 * @param msg message à enoyver
	 */
	public void sendMessage(final Message msg) {
		messageHandler.getMessageReceived().add(msg);
		if (!isReceiverInCache(msg)) {
			this.sendToNeighbours(msg);
		}
	}

	/**
	 * Envoie le message à tous les voisins du noeud
	 *
	 * @param msg message à envoyer
	 */
	private void sendToNeighbours(final Message msg) {
		for (final Cache voisin : getListNeighbor()) {
			msg.send(this.address, voisin.getAddress());
		}
	}

	public void setListNeighbor(final List<Cache> listNeighbor) {
		this.listNeighbor = listNeighbor;
	}

	public void setState(final State _state) {
		this.state = _state;
	}

	/**
	 * Met à jour le cache
	 *
	 * @param res
	 */
	public void updateCache(final GetInfoPerissableResponse res) {
		final Cache neigh = getCacheData(res.getIdUser());
		if (neigh != null) {
			neigh.setFirstName(res.getFirstName());
			neigh.setLastName(res.getLastName());
			neigh.setStatus(res.getStatus());
			neigh.setListPublication(res.getListPublication());
		}
	}

	/**
	 * Attend une réponse à la requête envoyée, si pas de réponse au bout d'un
	 * certain temps, alors celà veut dire que l'utilisateur est injoignable
	 *
	 * @param idFinalReceiver
	 * @param req
	 */
	public void waitForResponse(final int idFinalReceiver, final Request req) {
		new Timer().schedule(new TimerTask() {
			@Override
			public void run() {
				if (!messageHandler.isResponseReceived(req.getId())) {
					System.out.println("user " + idUser + " reçoit: user " + idFinalReceiver + " introuvable");
				}
			}
		}, 1000);
	}
}
