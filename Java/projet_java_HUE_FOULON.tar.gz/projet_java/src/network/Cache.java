package network;

public class Cache extends UserData {

	/**
	 * Crée un cache qui sert à stocker les données d'un utilisateur
	 *
	 * @param node noeud de l'utilisateur à mettre en cache
	 */
	public Cache(final Node node) {
		super(node.getIdUser(), node.getFirstName(), node.getLastName());
		this.address = node.getAddress();
	}

	@Override
	public final String toString() {
		return "User " + idUser + ": " + firstName;
	}
}
