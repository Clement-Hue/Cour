// Clément Hue
'use strict';
let album = {
    Fresh_Cream: 'Cream',
    Hot_Rats: 'Frank Zappa',
    Space_Oddity: 'David Bowie',
    Merry_Christmas: 'Mariah Carey',
    Songs_from_a_Room: 'Leonard Cohen',
    Ummagumma: 'Pink Floyd',
    Camembert_electrique: 'Gong',
    The_Piper_at_the_Gates_of_Dawn: 'Pink Floyd',
};
console.log(album.The_Piper_at_the_Gates_of_Dawn);