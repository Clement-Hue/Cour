package network;

public class Publication {
	private String text;
	private String date;

	/**
	 * Crée une publication
	 *
	 * @param text contenu de la publication
	 * @param date date à laquelle elle a été créée
	 */
	public Publication(final String text, final String date) {
		this.text = text;
		this.date = date;
	}

	public final String getDate() {
		return date;
	}

	public final String getText() {
		return text;
	}

	public final void setDate(final String date) {
		this.date = date;
	}

	public final void setText(final String text) {
		this.text = text;
	}

}
