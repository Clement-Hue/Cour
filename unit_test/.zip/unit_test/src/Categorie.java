enum Categorie { Quelconque, Equilateral, Isocele }
