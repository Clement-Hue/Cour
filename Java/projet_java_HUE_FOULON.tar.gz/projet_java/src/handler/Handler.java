package handler;

import message.request.GetAllNeighboursRequest;
import message.request.GetInfoPerissableRequest;
import message.request.GetInfoRequest;
import message.response.GetAllNeighboursResponse;
import message.response.GetInfoPerissableResponse;
import message.response.GetInfoResponse;
import network.Node;

public abstract class Handler {
	protected Node node;

	/**
	 * Traite le message reçu de type GetAllNeighboursRequest
	 *
	 * @param req requête reçue
	 */
	abstract public void handle(GetAllNeighboursRequest req);

	/**
	 * Traite le message reçu de type GetAllNeighboursResponse
	 *
	 * @param req requête reçue
	 */
	abstract public void handle(GetAllNeighboursResponse req);

	/**
	 * Traite le message reçu de type GetInfoPerissableRequest
	 *
	 * @param req requête reçue
	 */
	abstract public void handle(GetInfoPerissableRequest req);

	/**
	 * Traite le message reçu de type GetInfoPerissableResponse
	 *
	 * @param req requête reçue
	 */
	abstract public void handle(GetInfoPerissableResponse res);

	/**
	 * Traite le message reçu de type GetInfoRequest
	 *
	 * @param req requête reçue
	 */
	abstract public void handle(GetInfoRequest req);

	/**
	 * Traite le message reçu de type GetInfoResponse
	 *
	 * @param req requête reçue
	 */
	abstract public void handle(GetInfoResponse res);
}
