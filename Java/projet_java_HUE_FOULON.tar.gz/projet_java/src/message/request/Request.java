package message.request;

import message.Message;

public abstract class Request extends Message {
	public Request(final int idFirstSender, final int idFinalReceiver) {
		super(idFirstSender, idFinalReceiver);
	}
}
