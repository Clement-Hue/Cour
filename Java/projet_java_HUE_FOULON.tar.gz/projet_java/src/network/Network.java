package network;

import java.util.List;

public class Network {
	private static final int ARRAY_SIZE = 300;
	public static Node[] listNode = new Node[Network.ARRAY_SIZE];

	/**
	 * Ajoute un noeud et remplit son cache aléatoirement
	 *
	 * @param node noeud à ajouter
	 */
	public static void addNode(final Node node) {
		addToListNode(node);
		for (final Node currentNode : listNode) {
			if (currentNode != null && currentNode != node) {
				node.addUserToCache(currentNode);
			}
		}
	}

	/**
	 * Ajoute un noeud et lui affecte les noeuds en cache manuellement
	 *
	 * @param node         noeud à ajouter
	 * @param listNeighbor liste des voisins du noeud
	 */
	public static void addNode(final Node node, final List<Node> listNeighbor) {
		addToListNode(node);
		for (final Node neigh : listNeighbor) {
			node.addUserToCache(neigh);
		}
	}

	/**
	 * Ajoute le noeud à listNode à une position (adresse) aléatoire du tableau
	 *
	 * @param node
	 */
	private static void addToListNode(final Node node) {
		int index;
		do {
			index = (int) (Math.random() * Network.ARRAY_SIZE);
		} while (listNode[index] != null);
		listNode[index] = node;
		node.setAddress(index);
	}
}
