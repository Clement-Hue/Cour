class PrintObserver extends Observer {
    update(observable, object){
        console.log(observable.z)
    }
}