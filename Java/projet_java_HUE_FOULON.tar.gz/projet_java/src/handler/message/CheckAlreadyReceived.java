package handler.message;

import message.Message;
import message.request.GetAllNeighboursRequest;
import message.request.GetInfoPerissableRequest;
import message.request.GetInfoRequest;
import message.response.GetAllNeighboursResponse;
import message.response.GetInfoPerissableResponse;
import message.response.GetInfoResponse;
import network.Node;

// handler qui vérifie si le noeud a déjà reçu le message.
// Si déjà reçu, on ne le traite pas.
public class CheckAlreadyReceived extends MessageHandler {

	public CheckAlreadyReceived(final Node node) {
		super(node);
	}

	@Override
	public void handle(final GetAllNeighboursRequest res) {
		if (isAlreadyReceived(res))
			return;
		if (next != null) {
			next.handle(res);
		}
	}

	@Override
	public void handle(final GetAllNeighboursResponse res) {
		if (isAlreadyReceived(res))
			return;
		if (next != null) {
			next.handle(res);
		}
	}

	@Override
	public void handle(final GetInfoPerissableRequest req) {
		if (isAlreadyReceived(req))
			return;
		if (next != null) {
			next.handle(req);
		}
	}

	@Override
	public void handle(final GetInfoPerissableResponse res) {
		if (isAlreadyReceived(res))
			return;
		this.node.updateCache(res);
		if (next != null) {
			next.handle(res);
		}
	}

	@Override
	public void handle(final GetInfoRequest req) {
		if (isAlreadyReceived(req))
			return;
		if (next != null) {
			next.handle(req);
		}
	}

	@Override
	public void handle(final GetInfoResponse res) {
		if (isAlreadyReceived(res))
			return;
		if (next != null) {
			next.handle(res);
		}
	}

	/**
	 * Vérifie si le message est déjà arrivé sinon l'ajoute à messageReceived
	 *
	 * @param msg
	 * @return true si déjà arrivé
	 */
	private boolean isAlreadyReceived(final Message msg) {
		if (messageReceived.contains(msg)) {
			System.out.println("deja reçu");
			return true;
		}
		messageReceived.add(msg);
		return false;
	}

}
