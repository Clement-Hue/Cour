package handler.message;

import message.request.GetAllNeighboursRequest;
import message.request.GetInfoPerissableRequest;
import message.request.GetInfoRequest;
import message.response.GetAllNeighboursResponse;
import message.response.GetInfoPerissableResponse;
import message.response.GetInfoResponse;
import network.Node;

// handle qui fait le traitement du message.
public class TreatMessage extends MessageHandler {

	public TreatMessage(final Node node) {
		super(node);
	}

	@Override
	public void handle(final GetAllNeighboursRequest req) {
		node.getGetAllNeighbor().newResponse(req.getIdFirstSender(), req.getId(), node, false);
	}

	@Override
	public void handle(final GetAllNeighboursResponse res) {
		node.setListNeighbor(res.getData());
		System.out.println("noeud " + node.getIdUser() + " remplace ses voisins: " + node.getListNeighbor());
	}

	@Override
	public void handle(final GetInfoPerissableRequest req) {
		node.getGetInfoPerissable().newResponse(req.getIdFirstSender(), req.getId(), node, false);
	}

	@Override
	public void handle(final GetInfoPerissableResponse res) {
		System.out.println("noeud " + node.getIdUser() + " à reçu le statut: " + res.getStatus() + " de l'user: "
				+ res.getIdUser() + (res.isFromCache() ? " (cache)" : ""));
	}

	@Override
	public void handle(final GetInfoRequest req) {
	}

	@Override
	public void handle(final GetInfoResponse res) {
		System.out.println("noeud " + node.getIdUser() + " a reçu l'id user: " + res.getIdUser() + " de firstname: "
				+ res.getFirstName());
	}

}
