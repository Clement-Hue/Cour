package message.response;

import java.util.UUID;

import message.Message;

public abstract class Response extends Message {
	private final UUID requestId;
	protected boolean cache = false;

	public Response(final int idFirstSender, final int idFinalReceiver, final UUID requestId) {
		super(idFirstSender, idFinalReceiver);
		this.requestId = requestId;
	}

	public UUID getRequestId() {
		return requestId;
	}

	public final boolean isFromCache() {
		return cache;
	}

}
