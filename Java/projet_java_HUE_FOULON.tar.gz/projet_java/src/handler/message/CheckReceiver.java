package handler.message;

import message.Message;
import message.request.GetAllNeighboursRequest;
import message.request.GetInfoPerissableRequest;
import message.request.GetInfoRequest;
import message.response.GetAllNeighboursResponse;
import message.response.GetInfoPerissableResponse;
import message.response.GetInfoResponse;
import network.Cache;
import network.Node;

// handle qui vérifie le destinataire du message reçu.
public class CheckReceiver extends MessageHandler {

	public CheckReceiver(final Node node) {
		super(node);
	}

	@Override
	public void handle(final GetAllNeighboursRequest res) {
		if (!isThisMessageForMe(res)) {
			this.node.sendMessage(res);
		} else if (next != null) {
			next.handle(res);
		}
	}

	@Override
	public void handle(final GetAllNeighboursResponse res) {
		if (!isThisMessageForMe(res)) {
			this.node.sendMessage(res);
		} else if (next != null) {
			next.handle(res);
		}
	}

	@Override
	public void handle(final GetInfoPerissableRequest req) {
		if (!isThisMessageForMe(req)) {
			this.node.sendMessage(req);
		} else if (next != null) {
			next.handle(req);
		}
	}

	@Override
	public void handle(final GetInfoPerissableResponse res) {
		if (!isThisMessageForMe(res)) {
			this.node.sendMessage(res);
		} else if (next != null) {
			next.handle(res);
		}
	}

	@Override
	public void handle(final GetInfoRequest req) {
		if (!isThisMessageForMe(req)) {
			// je regarde s'il est pour un de mes voisins
			final Cache neigh = node.getCacheData(req.getIdFinalReceiver());
			// si oui, je reponds en envoyant les infos non perissables que j'ai sur ce
			// voisin
			if (neigh != null) {
				node.getGetInfo().newResponse(req.getIdFirstSender(), req.getId(), neigh, true);
			} else {
				node.sendMessage(req);
			}
		} else if (next != null) {
			next.handle(req);
		}
	}

	@Override
	public void handle(final GetInfoResponse res) {
		if (!isThisMessageForMe(res)) {
			this.node.sendMessage(res);
		} else if (next != null) {
			next.handle(res);
		}
	}

	/**
	 * Verifie si le noeud courant est le destinataire du message
	 *
	 * @param msg message reçu
	 */
	private boolean isThisMessageForMe(final Message msg) {
		if (node.getIdUser() == msg.getIdFinalReceiver())
			return true;
		return false;
	}

}
