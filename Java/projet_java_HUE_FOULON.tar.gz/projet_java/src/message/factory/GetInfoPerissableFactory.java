package message.factory;

import java.util.UUID;

import message.Message;
import message.request.GetInfoPerissableRequest;
import message.request.Request;
import message.response.GetInfoPerissableResponse;
import network.Node;
import network.UserData;

public class GetInfoPerissableFactory extends GetInfoFactory {

	public GetInfoPerissableFactory(final Node node) {
		super(node);
	}

	/**
	 * Crée une requête de type GetInfoPerissable
	 */
	@Override
	protected Request createRequest(final int idFinalReceiver) {
		return new GetInfoPerissableRequest(idFirstSender, idFinalReceiver);
	}

	/**
	 * Crée une réponse de type GetInfoPerissable
	 */
	@Override
	protected Message createResponse(final int idFinalReceiver, final UUID requestId, final UserData userData,
			final boolean cache) {
		return new GetInfoPerissableResponse(idFirstSender, idFinalReceiver, requestId, userData, cache);
	}

}
