package message;

import java.util.UUID;

import network.Network;

public abstract class Message {
	protected UUID id = UUID.randomUUID();
	protected int idFinalReceiver;
	protected int idFirstSender;
	protected int addressCurrentSender;

	public Message(final int idFirstSender, final int idFinalReceiver) {
		this.idFirstSender = idFirstSender;
		this.idFinalReceiver = idFinalReceiver;
	}

	public final int getAddressSender() {
		return addressCurrentSender;
	}

	public UUID getId() {
		return id;
	}

	public final int getIdFinalReceiver() {
		return idFinalReceiver;
	}

	public final int getIdFirstSender() {
		return idFirstSender;
	}

	abstract protected void performSending(int addressReceiver);

	protected void printNodeNotReachable() {
		System.out.println("user " + Network.listNode[addressCurrentSender].getIdUser() + " à recu NotReachableNode");
	}

	protected void printSending(final int addressSender, final int addressReceiver) {
		System.out.println("User " + Network.listNode[addressSender].getIdUser() + " envoie "
				+ this.getClass().getSimpleName() + " à User " + Network.listNode[addressReceiver].getIdUser());
	}

	/**
	 * Envoie la requête à l'adresse du receiver, si celui-ci est inatteignable une
	 * réponse NotReachableNode est renvoyée au sender
	 *
	 * @param addressSender   adresse du noeud courant envoyant la requéte
	 * @param addressReceiver adresse du noeud qui la recevra
	 */
	public void send(final int addressSender, final int addressReceiver) {
		this.setAddressSender(addressSender);
		this.performSending(addressReceiver);
	}

	public void setAddressSender(final int addressSender) {
		this.addressCurrentSender = addressSender;
	}

}