package network;

import java.util.List;

public class UserData {
	protected int address;
	protected int idUser;
	protected String firstName;
	protected String lastName;
	protected List<Publication> listPublication;
	protected String status;

	public UserData(final int idUser, final String firstName, final String lastName) {
		this.idUser = idUser;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public final int getAddress() {
		return address;
	}

	public final String getFirstName() {
		return firstName;
	}

	public final int getIdUser() {
		return idUser;
	}

	public final String getLastName() {
		return lastName;
	}

	public final List<Publication> getListPublication() {
		return listPublication;
	}

	public final String getStatus() {
		// System.out.println("user " + idUser + " a le statut: " + status);
		return status;
	}

	public final void setAddress(final int address) {
		this.address = address;
	}

	public final void setFirstName(final String firstName) {
		this.firstName = firstName;
	}

	public final void setIdUser(final int idUser) {
		this.idUser = idUser;
	}

	public final void setLastName(final String lastName) {
		this.lastName = lastName;
	}

	public final void setListPublication(final List<Publication> listPublication) {
		this.listPublication = listPublication;
	}

	public final void setStatus(final String status) {
		this.status = status;
	}
}
