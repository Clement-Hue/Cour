Compilation:
make
lancer l'exécutable:
./analyse
