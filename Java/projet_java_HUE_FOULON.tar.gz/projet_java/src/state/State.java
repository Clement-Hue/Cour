package state;

import network.Node;

public interface State {
	public void connection(Node node);

	public void disconnection(Node node);
}
