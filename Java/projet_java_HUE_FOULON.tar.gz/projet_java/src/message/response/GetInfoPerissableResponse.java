package message.response;

import java.util.List;
import java.util.UUID;

import network.Network;
import network.Publication;
import network.UserData;

// Répond à une requête GetInfoPerissable en envoyant toutes les informations du noeud.
public class GetInfoPerissableResponse extends GetInfoResponse {
	private final List<Publication> listPublication;
	private final String status;

	public GetInfoPerissableResponse(final int idFirstSender, final int idFinalReceiver, final UUID requestId,
			final UserData userData, final boolean cache) {
		super(idFirstSender, idFinalReceiver, requestId, userData, cache);
		this.status = userData.getStatus();
		this.listPublication = userData.getListPublication();
	}

	public final List<Publication> getListPublication() {
		return listPublication;
	}

	public final String getStatus() {
		return status;
	}

	@Override
	protected void performSending(final int addressReceiver) {
		try {
			printSending(addressCurrentSender, addressReceiver);
			Network.listNode[addressReceiver].getMessageHandler().handle(this);
		} catch (final NullPointerException exc) {
			printNodeNotReachable();
			Network.listNode[addressCurrentSender].getFailedHandler().handle(this);
		}
	}
}
