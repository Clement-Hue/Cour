import java.util.ArrayList;
import java.util.Scanner;

import network.Network;
import network.Node;

public class Test {

	public static void main(final String[] args) {
		final Scanner scanner = new Scanner(System.in);
		System.out.println("============= Test S1 =============");
		System.out.println("Action testée: U1 demande via son noeud N1 à consulter le statut de U3.");
		pressEnter(scanner);
		final Node node1 = new Node(1, "michel", "michel");
		final Node node2 = new Node(2, "richard", "anthony");
		final Node node3 = new Node(3, "antoine", "garnier");
		Network.addNode(node1, new ArrayList<>());
		Network.addNode(node2, new ArrayList<>());
		Network.addNode(node3, new ArrayList<>());
		node1.addUserToCache(node2);
		node2.addUserToCache(node3);
		node3.addUserToCache(node2);
		node2.addUserToCache(node1);
		System.out.println("adresse node1: " + node1.getAddress());
		System.out.println("adresse node2: " + node2.getAddress());
		System.out.println("adresse node3: " + node3.getAddress());
		node3.setStatus("Salut");
		node1.getGetInfoPerissable().newRequest(node3.getIdUser());

		System.out.println("============= Test S2 =============");
		System.out.println("Action testée : U1 demande via son noeud N1 à consulter le statut de U3.");
		System.out.println("Cas testé : Le noeud n'est pas joignable mais l'information est en cache.");
		pressEnter(scanner);
		node3.disconnection();
		node1.getGetInfoPerissable().newRequest(node3.getIdUser());

		System.out.println("============= Test S3 =============");
		System.out.println(
				"Action testée : U1 demande via son noeud N1 à consulter le statut de U5 (un identifiant d'utilisateur qui n'a pas lancé son noeud).");
		System.out.println("Cas testé : Le noeud n'est pas joignable et il y a un cycle dans les connexions.");
		pressEnter(scanner);
		node3.connection();
		final Node node4 = new Node(4, "benjamin", "button");
		Network.addNode(node4, new ArrayList<>());
		node3.addUserToCache(node4);
		node4.addUserToCache(node2);
		node1.getGetInfoPerissable().newRequest(5);

		System.out.println("============= Test S4 =============");
		System.out.println("Action testée : U11 demande via son noeud N11 à consulter le statut de U13.");
		System.out.println("Cas testé : Le noeud est connu mais pas joignable, et son statut n'est pas en cache.");
		pressEnter(scanner);
		final Node node11 = new Node(11, "sam", "gratt");
		final Node node12 = new Node(12, "joe", "ystick");
		final Node node13 = new Node(13, "tom", "hate");
		Network.addNode(node11, new ArrayList<>());
		Network.addNode(node12, new ArrayList<>());
		Network.addNode(node13, new ArrayList<>());
		node11.addUserToCache(node12);
		node12.addUserToCache(node13);
		node12.addUserToCache(node11);
		node13.addUserToCache(node12);
		node13.setStatus("Salut");
		node13.disconnection();
		node11.getGetInfoPerissable().newRequest(node13.getIdUser());
		System.out.println("============= Test P1 =============");
		System.out.println("Action testée : U1 demande via son noeud N1 à consulter le statut de U3.");
		System.out.println("Cas testé : sous la limite des 5 voisins.");
		pressEnter(scanner);
		node3.addUserToCache(node1);
		node1.getGetAllNeighbor().newRequest(node2.getIdUser());
		node2.disconnection();
		node1.getGetInfoPerissable().newRequest(node3.getIdUser());
		scanner.close();
	}

	private static void pressEnter(final Scanner scanner) {
		System.out.println("Appuyez sur entrée pour lancer le test");
		scanner.nextLine();
	}
}
