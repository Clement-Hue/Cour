package handler;

import handler.message.CheckAlreadyReceived;
import handler.message.CheckReceiver;
import handler.message.MessageHandler;
import handler.message.TreatMessage;
import network.Node;

public class HandlerFactory {

	/**
	 * Crée un handler qui traite les messages
	 *
	 * @param node noeud auquel est rattaché le handler
	 * @return Handler
	 */
	static public MessageHandler createHandler(final Node node) {
		final MessageHandler checkAlreadyReceived = new CheckAlreadyReceived(node);
		final MessageHandler checkReceiver = new CheckReceiver(node);
		final MessageHandler treatMessage = new TreatMessage(node);
		checkAlreadyReceived.setNext(checkReceiver);
		checkReceiver.setNext(treatMessage);
		return checkAlreadyReceived;
	}
}
