package handler.failMessage;

import handler.Handler;
import message.request.GetAllNeighboursRequest;
import message.request.GetInfoPerissableRequest;
import message.request.GetInfoRequest;
import message.response.GetAllNeighboursResponse;
import message.response.GetInfoPerissableResponse;
import message.response.GetInfoResponse;
import network.Cache;
import network.Node;

public class FailedMessageHandler extends Handler {

	public FailedMessageHandler(final Node node) {
		this.node = node;
	}

	@Override
	public void handle(final GetAllNeighboursRequest req) {
	}

	@Override
	public void handle(final GetAllNeighboursResponse req) {
	}

	@Override
	public void handle(final GetInfoPerissableRequest req) {
		final Cache neigh = node.getCacheData(req.getIdFinalReceiver());
		if (neigh != null && neigh.getStatus() != null) {
			if (req.getIdFirstSender() == node.getIdUser()) {
				System.out.println("noeud " + node.getIdUser() + " à reçu le statut: \"" + neigh.getStatus()
						+ "\" de l'user: " + neigh.getIdUser() + " venant de son cache");
			} else {
				node.getGetInfoPerissable().newResponse(req.getIdFirstSender(), req.getId(), neigh, true);
			}
		}
	}

	@Override
	public void handle(final GetInfoPerissableResponse res) {
	}

	@Override
	public void handle(final GetInfoRequest req) {
	}

	@Override
	public void handle(final GetInfoResponse res) {
	}

}
