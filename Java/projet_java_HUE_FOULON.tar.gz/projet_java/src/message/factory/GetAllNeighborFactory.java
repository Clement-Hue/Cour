package message.factory;

import java.util.UUID;

import message.Message;
import message.request.GetAllNeighboursRequest;
import message.request.Request;
import message.response.GetAllNeighboursResponse;
import network.Node;
import network.UserData;

public class GetAllNeighborFactory extends MessageFactory {

	public GetAllNeighborFactory(final Node node) {
		super(node);
	}

	/**
	 * Crée une requête de type GetAllNeighbor
	 */
	@Override
	protected Request createRequest(final int idFinalReceiver) {
		return new GetAllNeighboursRequest(idFirstSender, idFinalReceiver);
	}

	/**
	 * Crée une réponse de type GetAllNeighbor
	 */
	@Override
	protected Message createResponse(final int idFinalReceiver, final UUID requestId, final UserData userData,
			final boolean cache) {
		return new GetAllNeighboursResponse(idFirstSender, idFinalReceiver, requestId,
				((Node) userData).getListNeighbor());
	}
}
