package message.response;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import network.Cache;
import network.Network;

// Répond à une requête GetAllNeighbours en envoyant la table des voisins.
public class GetAllNeighboursResponse extends Response {
	private final List<Cache> data;

	public GetAllNeighboursResponse(final int idFirstSender, final int idFinalReceiver, final UUID requestId,
			final List<Cache> _data) {
		super(idFirstSender, idFinalReceiver, requestId);
		this.data = new ArrayList<>(_data);
		this.data.removeIf(cache -> cache.getIdUser() == idFinalReceiver);
	}

	public List<Cache> getData() {
		return this.data;
	}

	@Override
	protected void performSending(final int addressReceiver) {
		try {
			printSending(addressCurrentSender, addressReceiver);
			Network.listNode[addressReceiver].getMessageHandler().handle(this);
		} catch (final NullPointerException exc) {
			printNodeNotReachable();
			Network.listNode[addressCurrentSender].getFailedHandler().handle(this);
		}
	}

}
