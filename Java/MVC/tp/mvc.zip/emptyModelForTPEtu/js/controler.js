

class Controler extends Observer{

  constructor(model){
    super()
      this.view = new View();
      this.model = model;
      this.model.addObservers(this);
      // update
      //  action
      this.view.buttonPlus.addEventListener("click", this.model.plus)
      this.view.buttonMoins.addEventListener("click", this.model.moins)
  }

  update(observable, object) {
    if (observable.z === 0) {
      this.view.buttonMoins.disabled= true;
    } else {
      this.view.buttonMoins.disabled= false;
    }
    if (observable.z === 10) {
      this.view.buttonPlus.disabled= true;
    } else {
      this.view.buttonPlus.disabled= false;
    }
  }
}
