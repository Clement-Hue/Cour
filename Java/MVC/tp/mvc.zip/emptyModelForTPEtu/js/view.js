
class View {
  buttonPlus = document.getElementById("plus");;
  buttonMoins = document.getElementById("moins");
  text = document.getElementById("text");
}
