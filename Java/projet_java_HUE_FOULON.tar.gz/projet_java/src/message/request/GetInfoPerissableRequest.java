package message.request;

import network.Network;

// Requête envoyée à un noeud particulier pour récupérer toutes ses informations, périssables et non périssables.
public class GetInfoPerissableRequest extends GetInfoRequest {
	public GetInfoPerissableRequest(final int idFirstSender, final int idFinalReceiver) {
		super(idFirstSender, idFinalReceiver);
	}

	@Override
	protected void performSending(final int addressReceiver) {
		try {
			printSending(addressCurrentSender, addressReceiver);
			Network.listNode[addressReceiver].getMessageHandler().handle(this);
		} catch (final NullPointerException exc) {
			printNodeNotReachable();
			Network.listNode[addressCurrentSender].getFailedHandler().handle(this);
		}
	}
}
