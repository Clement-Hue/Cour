// Clément Hue
'use strict';
console.log('Hello World!');