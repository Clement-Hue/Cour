package handler.message;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import handler.Handler;
import message.Message;
import message.response.Response;
import network.Node;

public abstract class MessageHandler extends Handler {
	protected MessageHandler next;
	protected Set<Message> messageReceived = new HashSet<>();

	public MessageHandler(final Node node) {
		this.node = node;
	}

	public Set<Message> getMessageReceived() {
		return messageReceived;
	}

	/**
	 * Check si une réponse à une requête donnée est reçue
	 *
	 * @param requestId id de la requête
	 * @return true si la réponse est reçue
	 */
	public boolean isResponseReceived(final UUID requestId) {
		for (final Message res : messageReceived) {
			if (res instanceof Response && ((Response) res).getRequestId() == requestId)
				return true;
		}
		return false;
	}

	public void setNext(final MessageHandler messageHandler) {
		this.next = messageHandler;
	}

}
