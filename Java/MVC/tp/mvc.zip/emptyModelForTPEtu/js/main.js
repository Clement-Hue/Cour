// define the dictionary
$.i18n().load( {
    'fr' : {
      'key' : 'value',
    },
    'en': {
    }
})

// set the locale
$.i18n( {
    locale: 'en'
    //locale : navigator.language
} );


const model = new ModelInteger();
const printObserver = new PrintObserver();
model.addObservers(printObserver);

const controler = new Controler(model);
